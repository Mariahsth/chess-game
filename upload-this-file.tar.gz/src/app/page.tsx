import Home from "./home/page";

export default function Page() {
  return <Home />;
}
