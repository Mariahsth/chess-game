"use client";
import styles from "./Play.module.css";
import { useRouter } from "next/navigation";
import { useGameContext } from "../context/GameContext";

export default function Play() {
  const { valueX, valueY } = useGameContext();
  const router = useRouter();

  return (
    <>
      <div className={styles.page}>
        <div
          className={styles.board_dynamic}
          style={{
            display: "grid",
            gridTemplateColumns: `repeat(${valueX}, 40px)`,
            gridTemplateRows: `repeat(${valueY}, 40px)`,
            marginTop: "20px",

            borderRadius: "8px",
            overflow: "hidden",
          }}
        >
          {Array.from({ length: valueX * valueY }).map((_, index) => (
            <div
              key={index}
              style={{
                width: "40px",
                height: "40px",
                boxShadow: "0 10px 30px rgba(0, 0, 0, 0.6)",
                backgroundColor:
                  (Math.floor(index / valueX) + (index % valueY)) % 2 === 0
                    ? "#646262"
                    : "#3d3b3b",
              }}
            />
          ))}
        </div>
      </div>
    </>
  );
}
